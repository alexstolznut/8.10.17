﻿(function () {
    "use strict";

    document.addEventListener('deviceready', onDeviceReady.bind(this), false);

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener('pause', onPause.bind(this), false);
        document.addEventListener('resume', onResume.bind(this), false);
        document.addEventListener('backbutton', function(event){onBackKeyDown(event)}, false);

        navigator.splashscreen.hide();
        console.log("ready!");


        var $elFormSignUp = $("#formSignUp");
        var $elFormLogIn = $("#formLogIn");
        var $elBtnLogOut = $("#btnLogOut");
        var $elUserEmail = $(".userEmail");
        var $elBtnContact = $("#btnContact");

        // Code to check if a user has logged in previously
        if (localStorage.getItem("isLoggedIn") === undefined || localStorage.getItem("isLoggedIn") === null || localStorage.getItem("isLoggedIn") === "") {
            console.log("Is NOT logged in: " + localStorage.getItem("isLoggedIn"));
        } else {
            console.log("YES IS logged in: " + localStorage.getItem("isLoggedIn"));
            // Move Use from #pgWelcome to #pgHome, with various options
            $(":mobile-pagecontainer").pagecontainer("change", "#pgHome", { "transition": "flip"});
            // Also write the User's email to the Footers [because we didn't use fnLogIn()]
            $elUserEmail.html(localStorage.getItem("isLoggedIn").toLowerCase());
        } // END If...Else checking if a User is logged in

        // Use the JS keywork function to create a 'bundle of Methods'
        function fnSignUp(event) {
            console.log("---START fnSignUp()");
            event.preventDefault();

            // Create 3 JQ Variables to hold the Input Field Nodes
            var $elInEmailSignUp = $("#inEmailSignUp"),
                $elInPasswordSignUp = $("#inPasswordSignUp"),
                $elInPasswordConfirmSignUp = $("#inPasswordConfirmSignUp");

            console.log($elInEmailSignUp.val(), $elInPasswordSignUp.val(), $elInPasswordConfirmSignUp.val());

            // If...Else checks for two possiblities
            // If part checks for True/False of something. If TRUE,
            // do the part in the first pair of Curly Braces.
            // If FALSE, do the part in the second pair of Curlys.
            // Check if both passwords ARE NOT !== equal to each other
            if ($elInPasswordSignUp.val() !== $elInPasswordConfirmSignUp.val()) {
                console.log("PASSWORD DO NOT MATCH");
                $elInPasswordSignUp.val(""); // Reset the Input to empty
                $elInPasswordConfirmSignUp.val("");
                $("#popErrorSignUpMismatch").popup(); // Prepare a Popup Message
                $("#popErrorSignUpMismatch").popup("open", { "positionTo": "open", "transition": "flip" });
            } else {
                console.log("Passwords DO match");
                var tmpValInEmailSignUp = $elInEmailSignUp.val().toUpperCase(),
                    tmpValInPasswordSignUp = $elInPasswordSignUp.val().toUpperCase();
                console.log("Saved email: " + tmpValInEmailSignUp, "Saved password: " + tmpValInPasswordSignUp);
                // Check if the user's email exists already
                if (localStorage.getItem(tmpValInEmailSignUp) === null) {
                    console.log("tmpValInEmailSignUp DOES NOT exist");
                    localStorage.setItem(tmpValInEmailSignUp, tmpValInPasswordSignUp); // Save the email/password in permanent storage
                    console.log("Cookie saved: " + localStorage.getItem(tmpValInEmailSignUp));
                    $elFormSignUp[0].reset();
                    $("#popSuccessSignUp").popup();
                    $("#popSuccessSignUp").popup("open", { "positionTo": "window", "transition": "flip" });
                } else {
                    console.log("tmpValInEmailSignUp DOES exist!!");
                    $("#popErrorSignUpExists").popup();
                    $("#popErrorSignUpExists").popup("open", { "positionTo": "window", "transition": "flip" });
                } //END If...Else of checking for user existing
            } // END If...Else of checking password match
            console.log("---END fnSignUp()");
        } // END fnSignUp()

        function fnLogIn(event) {
            console.log("=== START fnLogIn()");
            event.preventDefault();

            var $elInEmailLogIn = $("#inEmailLogIn"),
                $elInPasswordLogIn = $("#inPasswordLogIn"),
                tmpValInEmailLogIn = $elInEmailLogIn.val().toUpperCase(),
                tmpValInPasswordLogIn = $elInPasswordLogIn.val().toUpperCase();

            console.log("Email is: " + tmpValInEmailLogIn, "PWD is: " + tmpValInPasswordLogIn);

            // Check if the attempted email log does not exist (null)
            if (localStorage.getItem(tmpValInEmailLogIn) === null) {
                console.log("This user doesn't exist: " + tmpValInEmailLogIn);
                $("#popLogInNonexistant").popup();
                $("#popLogInNonexistant").popup("open", { "positionTo": "window", "transition": "flip" });
            } else {
                console.log("This user DOES exist: " + tmpValInEmailLogIn);
                if (tmpValInPasswordLogIn === localStorage.getItem(tmpValInEmailLogIn)) {
                    console.log("Password MATCH!");
                    // Via JS, change from the current page, to a new page (<section>)
                    $(":mobile-pagecontainer").pagecontainer("change", "#pgHome", { "transition": "flip" });
                    // Write the user's email at the footer of a screen (h4)
                    $elUserEmail.html(tmpValInEmailLogIn.toLowerCase());
                    // Store the email of who last logged in, in localStorage
                    localStorage.setItem("isLoggedIn", tmpValInEmailLogIn);
                } else {
                    console.log("Password DO NOT Match!");
                    $("#popLogInIncorrect").popup();
                    $("#popLogInIncorrect").popup("open", { "positionTo": "window", "transition": "flip" });
                    $elInPasswordLogIn.val("");
                } // END If...Else of checking password
            } // END If...Else of checking user existence
            console.log("=== END fnLogIn()");
        } // END fnLogIn()

        function fnLogOut() {
            console.log("=== START fnLogOut()");
            $(":mobile-pagecontainer").pagecontainer("change", "#pgWelcome");
            // Reset the localStorage of who has last logged in to null (empty)
            localStorage.setItem("isLoggedIn", "");
        } // END fnLogOut()

        function fnContact() {
            window.plugins.socialsharing.shareViaEmail(
                "Regarding your app...<br>", // Message Body ("String")
                "CBDb Feedback", // Email Subject ("String")
                ["vcampos@school.com"], // To: Emails in Array  of "Strings"
                null, // CC: Emails in Array of "Strings"
                null, // BCC: Emails in Array of "Strings"
                "www/images/cordova.png", // Attachments, in your www folder
                function (success) { console.log("SUCCESS") }, // Success callback (Function)
                function (failure) { console.log("fail") }  // Failure callback (Function)
            );
        }

        var $elFormSaveComic = $("#formSaveComic"),
            $elDivShowComicsTable = $("#divShowComicsTable"),
            $elBtnDeleteCollection = $("#btnDeleteCollection"),
            db; // Set up Database Variable don't "connect" w/ PouchDB, yet.

        // Function to Initialize the Database whenever we need it.
        function initDB() {
            // Create a new instance of the PouchDB Object (database).
            db = new PouchDB("myComics");
            // Return the Object to the Global Scope.
            return db;
        } // END initDB()

        initDB(); // Initilize that database
        //console.log(db.info()); // Show the database.

        function fnGetFirstWord(str) {
            if (str.indexOf(" ") === -1) {
                // Check if the comic only has a one word Title
                // And then just return it, unprocessed
                return str;
            } else {
                // Or else, it then has multiple words in Title
                // Create a new string (substring), where we remove
                // everything after the first word
                return str.substr(0, str.indexOf(" "));
            }
        } // END fnGetFirstWord()

        // Function to get the data from the fields and prepare
        // it to be saved to PouchDB.
        function fnPrepComic() {
            // Prevent the default behavior of submitting a Form (don't refresh).
            // event.preventDefault();
            // console.log("Getting the data from the fields");

            // Gather the Values of the Input Fields
            var $valInTitle = $("#inTitle").val(),
                $valInNumber = $("#inNumber").val(),
                $valInYear = $("#inYear").val(),
                $valInPublisher = $("#inPublisher").val(),
                $valInComment = $("#inComment").val();

            /*console.log($valInTitle, $valInNumber, $valInYear, 
                        $valInPublisher, $valInComment); */

            var tmpID1 = fnGetFirstWord($valInTitle).toUpperCase(),
                tmpID2 = $valInTitle.toUpperCase(),
                tmpID3 = "";

            // Switch Statement to check known possibilities
            switch (tmpID1) {
                case "THE":
                    //console.log("The comic had THE");
                    // 1st. Strip out "THE" from Title
                    tmpID3 = tmpID2.replace("THE ", "");
                    // 2nd. Only select the first 3 letters of Title
                    tmpID3 = tmpID3.substr(0, 3);
                    break;
                case "A":
                    //console.log("The comic had A");
                    tmpID3 = tmpID2.replace("A ", "");
                    tmpID3 = tmpID3.substr(0, 3);
                    break;
                case "AN":
                    //console.log("The comid had AN");
                    tmpID3 = tmpID2.replace("AN ", "");
                    tmpID3 = tmpID3.substr(0, 3);
                    break;
                default:
                    //console.log("The comic had neither");
                    tmpID3 = tmpID2.substr(0, 3);
                    break;
            }

            // Bundle the data in JSON format
            // For PouchDB, WE MUST HAVE AN _id Field
            var comic = {
                "_id": tmpID3 + $valInNumber,
                "title": $valInTitle,
                "number": $valInNumber,
                "year": $valInYear,
                "publisher": $valInPublisher,
                "comment": $valInComment,
                "uniqueid": $valInTitle.replace(/\s/g, "").toUpperCase() + $valInNumber + $valInYear
            };
            // .replace() searches through a String (/) for Whitespace (\s),
            // then replaces all instances (/g) with nothing ("")
            // "The Amazing Spider-Man"  ==> "TheAmazingSpider-Man"
            // Known as a RegEx  (Regular Expression) 

            // Displays the whole JSON object
            //console.log(comic);
            //console.log(comic.barcode);

            return comic;
        } // END fnPrepComic()

        function fnSaveComic(event) {
            event.preventDefault();

            var aComic = fnPrepComic();
            console.log(aComic);
            console.log(aComic._id);

            // PouchDB command (Method) to put the data in the DB
            // Two possiblities to handle in a Callback Function
            db.put(aComic, function (failure, success) {
                if (failure) {
                    // console.log("FAILED: " + failure);
                    switch (failure.status) {
                        case 409:
                            console.log("ID already exists");
                            //alert("Comic already exists");

                            db.get(aComic._id, function (failure, success) {
                                if (failure) {
                                    console.log(failure);
                                } else {
                                    console.log("Old comic: " + success.uniqueid);
                                    console.log("New comic: " + aComic.uniqueid);
                                    if (success.uniqueid === aComic.uniqueid) {
                                        // Exact same comic
                                        alert("You already saved this comic!");
                                    } else {
                                        // Different comic
                                        var idTmp = aComic._id,
                                            idTmpRandom = Math.round(Math.random() * 99);
                                        aComic._id = idTmp + idTmpRandom;
                                        db.put(aComic);
                                    }
                                }
                            });
                            $elFormSaveComic[0].reset();
                            break;
                        case 412:
                            console.log("ID is empty");
                            alert("Title & Number CANNOT be empty!");
                            break;
                        default:
                            console.log(failure.status);
                            alert("Unknown error - Contact the developer: help@trashcan.xyz");
                            break;
                    }
                } else {
                    console.log("SUCCEEDED: " + success.ok);
                    $("#popSavedComic").popup;
                    $("#popSavedComic").popup("open", { "positionTo": "open", "transition": "flip" });;
                    $elFormSaveComic[0].reset();
                    fnShowComicsPrep();
                    /* 
                        To delete the PouchDB database in Chrome,
                        run the following command in the Console (Dev Mode F12):
                        indexedDB.deleteDatabase("_pouch_myComics");
                    */
                } // END of If..Else of .put()
            }); // END of .put()
        } // END fnSaveComic(event)

        function fnShowComicsPrep() {
            // Get all the Docs (data) from the database (PouchDB)
            // With options (in JSON format) of including all the actual Doc data
            // And alphabetized, ascending (A-Z), too
            db.allDocs({ "include_docs": true, "ascending": true }, function (failure, success) {
                if (failure) {
                    console.log(failure);
                } else {
                    // Output the raw data from the Db
                    console.log(success.rows);
                    // Out put the Title, of the current Doc (the 4th one)z
                    //console.log(success.rows[3].doc.title);
                    fnShowComicsTable(success.rows);
                }
            });
        } // END fnShowComicsPrep()

        function fnShowComicsTable(data) {
            var str = "<p><table border='1'>";
            str += "<tr><th>Name</th><th>#</th><th>Info</th></tr>";
            for (var i = 0; i < data.length; i++) {
                /*
                    Create a row with a data-id of the _id of the Comic
                    Display in a Cell the Title, and # of the Comic
                    Also, display a "Read More" Icon (&#x1F4AC;) which
                    has an Active Link.
                */
                str += "<tr data-id='" + data[i].doc._id +
                    "'><td>" + data[i].doc.title +
                    "</td><td>" + data[i].doc.number +
                    "</td><td class='btnShowComicsInfo'><a href='#'>&#x1F4AC;</a></td></tr>";
            }
            str += "</table></p>";
            $elDivShowComicsTable.html(str);
        } // END fnShowComicsTable(data)

        fnShowComicsPrep();

        function fnShowComicsInfo(thisComic) {
            // Output the data (ALL THE DATA) representing the row (<tr>)
            console.log(thisComic);
            // Output the info of data-id= Attribute of the row (<tr>)
            console.log(thisComic.data("id"));
           
            var tmpComic = thisComic.data("id");
            db.get(tmpComic, function (failure, success) {
                if (failure) {
                    console.log(failure);
                } else {
                    console.log(success);
                    // jQuery selector to target the Parent Div (#divShowComicsInfo)
                    // AND the zeroth (1st) Paragraph, to write HTML into it
                    $("#divShowComicsInfo p:eq(0)").html("Name: " + success.title);
                    $("#divShowComicsInfo p:eq(1)").html("Number: " + success.number);
                    $("#divShowComicsInfo p:eq(2)").html("Year: " + success.year);
                    $("#divShowComicsInfo p:eq(3)").html("Publisher: " + success.publisher);
                    $("#divShowComicsInfo p:eq(4)").html("Comment: " + success.comment);
                    $("#popViewComicsInfo").popup();
                    $("#popViewComicsInfo").popup("open", { "positionTo": "open", "transition": "flip" });
                }
            });
        } // END fnShowComicsInfo(thisComic)

        function fnDeleteCollection() {
            switch (confirm("You are about to delete your whole collection. \nConfirm?")) {
                case true:
                    if (confirm("are you sure...?")){
                        db.destroy(function (failure, success) {
                            if (failure) {
                                console.log(failure);
                                alert("ERROR \nContact the developer!");
                            } else {
                                console.log(success);
                                fnShowComicsPrep();
                                fnShowComicsPrep();
                                initDB();
                            }
                        });
                    } else {

                    }
                    break;
                case false:
                    console.log("user cancelled");
                    break;
                default:
                    console.log("error - third option selected");
                    break;
            }
        }// END of fnDeleteCollection

        
        /* *** Event Handlers *** */
        $elFormSignUp.submit(function (event) { fnSignUp(event) });
        $elFormLogIn.submit(function (event) { fnLogIn(event) });
        $elBtnLogOut.on("click", fnLogOut);
        $elBtnContact.on("click", fnContact);
        // Event Handler for Submittal, and capture the Event (to prevent default).
        $elFormSaveComic.submit(function (event) { fnSaveComic(event) });
        // Target an HTML element that exists at runtime ($elDivShowComicsTable), 
        // then a dynamic element (.btnShowComicsInfo), to listen for a click
        // then run a function (fnShowComicsInfo), which
        // we pass into it, the jQ object $(this) [literally, THIS object we clicked]
        // refined to the Parent element (the <tr>) with jQ .parent()
        $elDivShowComicsTable.on("click", ".btnShowComicsInfo",
            function () { fnShowComicsInfo($(this).parent()) });
        //SImpler way to access a function if it doesn't need a parameter {no parentheses}'
        $elBtnDeleteCollection.on("click", fnDeleteCollection)
    
    } // END onDeviceReady()

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    }

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    }

    function onBackKeyDown(event) {
        console.log("Back Key was prevented!");
        event.preventDefault();
    }
})();