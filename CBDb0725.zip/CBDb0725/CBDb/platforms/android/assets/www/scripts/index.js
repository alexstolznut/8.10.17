﻿(function () {
    "use strict";

    document.addEventListener('deviceready', onDeviceReady.bind(this), false);

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener('pause', onPause.bind(this), false);
        document.addEventListener('resume', onResume.bind(this), false);
        document.addEventListener('backbutton', function(event){onBackKeyDown(event)}, false);

        navigator.splashscreen.hide();
        console.log("ready!");


        var $elFormSignUp = $("#formSignUp");
        var $elFormLogIn = $("#formLogIn");
        var $elBtnLogOut = $("#btnLogOut");
        var $elUserEmail = $(".userEmail");
        var $elBtnContact = $("#btnContact");

        // Code to check if a user has logged in previously
        if (localStorage.getItem("isLoggedIn") === undefined || localStorage.getItem("isLoggedIn") === null || localStorage.getItem("isLoggedIn") === "") {
            console.log("Is NOT logged in: " + localStorage.getItem("isLoggedIn"));
        } else {
            console.log("YES IS logged in: " + localStorage.getItem("isLoggedIn"));
            // Move Use from #pgWelcome to #pgHome, with various options
            $(":mobile-pagecontainer").pagecontainer("change", "#pgHome", { "transition": "flip"});
            // Also write the User's email to the Footers [because we didn't use fnLogIn()]
            $elUserEmail.html(localStorage.getItem("isLoggedIn").toLowerCase());
        } // END If...Else checking if a User is logged in

        // Use the JS keywork function to create a 'bundle of Methods'
        function fnSignUp(event) {
            console.log("---START fnSignUp()");
            event.preventDefault();

            // Create 3 JQ Variables to hold the Input Field Nodes
            var $elInEmailSignUp = $("#inEmailSignUp"),
                $elInPasswordSignUp = $("#inPasswordSignUp"),
                $elInPasswordConfirmSignUp = $("#inPasswordConfirmSignUp");

            console.log($elInEmailSignUp.val(), $elInPasswordSignUp.val(), $elInPasswordConfirmSignUp.val());

            // If...Else checks for two possiblities
            // If part checks for True/False of something. If TRUE,
            // do the part in the first pair of Curly Braces.
            // If FALSE, do the part in the second pair of Curlys.
            // Check if both passwords ARE NOT !== equal to each other
            if ($elInPasswordSignUp.val() !== $elInPasswordConfirmSignUp.val()) {
                console.log("PASSWORD DO NOT MATCH");
                $elInPasswordSignUp.val(""); // Reset the Input to empty
                $elInPasswordConfirmSignUp.val("");
                $("#popErrorSignUpMismatch").popup(); // Prepare a Popup Message
                $("#popErrorSignUpMismatch").popup("open", { "positionTo": "open", "transition": "flip" });
            } else {
                console.log("Passwords DO match");
                var tmpValInEmailSignUp = $elInEmailSignUp.val().toUpperCase(),
                    tmpValInPasswordSignUp = $elInPasswordSignUp.val().toUpperCase();
                console.log("Saved email: " + tmpValInEmailSignUp, "Saved password: " + tmpValInPasswordSignUp);
                // Check if the user's email exists already
                if (localStorage.getItem(tmpValInEmailSignUp) === null) {
                    console.log("tmpValInEmailSignUp DOES NOT exist");
                    localStorage.setItem(tmpValInEmailSignUp, tmpValInPasswordSignUp); // Save the email/password in permanent storage
                    console.log("Cookie saved: " + localStorage.getItem(tmpValInEmailSignUp));
                    $elFormSignUp[0].reset();
                    $("#popSuccessSignUp").popup();
                    $("#popSuccessSignUp").popup("open", { "positionTo": "window", "transition": "flip" });
                } else {
                    console.log("tmpValInEmailSignUp DOES exist!!");
                    $("#popErrorSignUpExists").popup();
                    $("#popErrorSignUpExists").popup("open", { "positionTo": "window", "transition": "flip" });
                } //END If...Else of checking for user existing
            } // END If...Else of checking password match
            console.log("---END fnSignUp()");
        } // END fnSignUp()

        function fnLogIn(event) {
            console.log("=== START fnLogIn()");
            event.preventDefault();

            var $elInEmailLogIn = $("#inEmailLogIn"),
                $elInPasswordLogIn = $("#inPasswordLogIn"),
                tmpValInEmailLogIn = $elInEmailLogIn.val().toUpperCase(),
                tmpValInPasswordLogIn = $elInPasswordLogIn.val().toUpperCase();

            console.log("Email is: " + tmpValInEmailLogIn, "PWD is: " + tmpValInPasswordLogIn);

            // Check if the attempted email log does not exist (null)
            if (localStorage.getItem(tmpValInEmailLogIn) === null) {
                console.log("This user doesn't exist: " + tmpValInEmailLogIn);
                $("#popLogInNonexistant").popup();
                $("#popLogInNonexistant").popup("open", { "positionTo": "window", "transition": "flip" });
            } else {
                console.log("This user DOES exist: " + tmpValInEmailLogIn);
                if (tmpValInPasswordLogIn === localStorage.getItem(tmpValInEmailLogIn)) {
                    console.log("Password MATCH!");
                    // Via JS, change from the current page, to a new page (<section>)
                    $(":mobile-pagecontainer").pagecontainer("change", "#pgHome", { "transition": "flip" });
                    // Write the user's email at the footer of a screen (h4)
                    $elUserEmail.html(tmpValInEmailLogIn.toLowerCase());
                    // Store the email of who last logged in, in localStorage
                    localStorage.setItem("isLoggedIn", tmpValInEmailLogIn);
                } else {
                    console.log("Password DO NOT Match!");
                    $("#popLogInIncorrect").popup();
                    $("#popLogInIncorrect").popup("open", { "positionTo": "window", "transition": "flip" });
                    $elInPasswordLogIn.val("");
                } // END If...Else of checking password
            } // END If...Else of checking user existence
            console.log("=== END fnLogIn()");
        } // END fnLogIn()

        function fnLogOut() {
            console.log("=== START fnLogOut()");
            $(":mobile-pagecontainer").pagecontainer("change", "#pgWelcome");
            // Reset the localStorage of who has last logged in to null (empty)
            localStorage.setItem("isLoggedIn", "");
        } // END fnLogOut()

        function fnContact() {
            window.plugins.socialsharing.shareViaEmail(
                "Regarding your app...<br>", // Message Body ("String")
                "CBDb Feedback", // Email Subject ("String")
                ["vcampos@school.com"], // To: Emails in Array  of "Strings"
                null, // CC: Emails in Array of "Strings"
                null, // BCC: Emails in Array of "Strings"
                "www/images/cordova.png", // Attachments, in your www folder
                function (success) { console.log("SUCCESS") }, // Success callback (Function)
                function (failure) { console.log("fail") }  // Failure callback (Function)
            );
        }

        /* *** Event Handlers *** */
        $elFormSignUp.submit(function (event) { fnSignUp(event) });
        $elFormLogIn.submit(function (event) { fnLogIn(event) });
        $elBtnLogOut.on("click", fnLogOut);
        $elBtnContact.on("click", fnContact);
    } // END onDeviceReady()

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    }

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    }

    function onBackKeyDown(event) {
        console.log("Back Key was prevented!");
        event.preventDefault();
    }
})();